add_.php
<?php
session_start();

$servername="localhost";
$username="root";
$password="";
$database="admin90";
$conn=mysqli_connect($servername,$username,$password,$database);
if ($conn) {
   echo "database successfully connected"."<br>";
}else{
   echo "database is not connectred";
}
if (isset($_POST['submit'])) {
	$cont=$_POST['cont'];
	$cont1=$_POST['cont1'];
	$cont2=$_POST['cont2'];
	$cont3=$_POST['cont3'];
	
	
	//echo $cont3;die;
	$sql="INSERT INTO `create`(`content1`, `content2`, `content3`, `content4`) VALUES ('$cont','$cont1','$cont2','$cont3')";
	
	$result = mysqli_query($conn, $sql);
	//echo $result;die;
	if ($sql) {
		header('location:create.php');
	}else{
		echo "not create record";
	}

}








?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>NobleUI Responsive Bootstrap 4 Dashboard Template</title>
	<!-- core:css -->
	<link rel="stylesheet" href="assets/vendors/core/core.css">
	<!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css">
	<!-- end plugin css for this page -->
	<!-- inject:css -->
	<link rel="stylesheet" href="/assets/fonts/feather-font/css/iconfont.css">
	<link rel="stylesheet" href="assets/vendors/flag-icon-css/css/flag-icon.min.css">
	<!-- endinject -->
  <!-- Layout styles -->  
	<link rel="stylesheet" href="assets/css/demo_1/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="assets/images/favicon.png" />

  

</head>
<body>
	<div class="main-wrapper">

		<!-- partial:partials/_sidebar.html -->
		<nav class="sidebar" >
      <div class="sidebar-header">
        <a href="#" class="sidebar-brand">
          Sudhir<span>UI</span>
        </a>
        <div class="sidebar-toggler not-active">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
      <div class="sidebar-body">
        <ul class="nav">
          <li class="nav-item nav-category">Main</li>
          <li class="nav-item">
            <a class="nav-link">
              <i class="link-icon" data-feather="box"></i>
              <span class="link-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item nav-category">Components</li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#uiComponents" role="button" aria-expanded="false" aria-controls="uiComponents">
              <i class="link-icon" data-feather="feather"></i>
              <span class="link-title">Banner</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="uiComponents">
              <ul class="nav sub-menu">
                <li class="nav-item">
                  <a href="add_banner.php" class="nav-link">Add Banner</a>
                </li>
                <li class="nav-item">
                  <a href="view_banner.php" class="nav-link">View Banner</a>
                </li>
                <li class="nav-item">
                  <a href="edit_banner.php" class="nav-link">Edit Banner</a>
                </li>
                <li class="nav-item">
                  <a href="delete_banner.php" class="nav-link">Delete Banner</a>
                </li>
              </ul>
            </div>
          </li>
          <li class="nav-item nav-category">Content</li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#general-pages" role="button" aria-expanded="false" aria-controls="general-pages">
              <i class="link-icon" data-feather="book"></i>
              <span class="link-title">Web Page</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="general-pages">
              <ul class="nav sub-menu">
                <li class="nav-item">
                  <a href="innovate.php" class="nav-link">Innovate</a>
                </li>
                <li class="nav-item">
                  <a href="create.php" class="nav-link">Create</a>
                </li>
                <li class="nav-item">
                  <a href="Scale.php" class="nav-link">Scale</a>
                </li>

                <li class="nav-item">
                  <a href="" class="nav-link">Buttoms</a>
                </li>
                <li class="nav-item">
                  <a href="Our_works.php" class="nav-link">Our Works</a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link">Testimonials</a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link">Our Services</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">About Us</a>
                  </li>
                <li class="nav-item">
                  <a href="#" class="nav-link">Our Teams</a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link">Blogp</a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link">Contact Us</a>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </nav>





   
		<!-- partial -->
	
		<div class="page-wrapper">
					
			<!-- partial:partials/_navbar.html -->
			<nav class="navbar">
				<a href="#" class="sidebar-toggler">
					<i data-feather="menu"></i>
				</a>
				<div class="navbar-content">
					
					<ul class="navbar-nav">
						<li class="nav-item dropdown nav-profile">
							<a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<img src="uploads/<?php echo $_SESSION['user']; ?>" alt="profile">
							</a>
								<div class="dropdown-menu" aria-labelledby="profileDropdown">
								<div class="dropdown-header d-flex flex-column align-items-center">
									<div class="figure mb-3">
										<img src="uploads/<?php echo $_SESSION['user']; ?>" alt=""><!-- 2nd image of profile-->
									</div>
									<div class="info text-center">
										<p class="name font-weight-bold mb-0"><?php echo $_SESSION["name"]; ?></p>
										<p class="email text-muted mb-3"><?php echo $_SESSION["email"]; ?></p>
									</div>
								</div>
								<div class="dropdown-body">
									<ul class="profile-nav p-0 pt-3">
										<li class="nav-item">
											<a href="imagePro.php" class="nav-link">
												<i data-feather="edit"></i>
												<span>Edit Profile</span>
											</a>
										</li>
										<li class="nav-item">
											<a href="login.php" class="nav-link">
												<i data-feather="repeat"></i>
												<span>Switch User</span>
											</a>
										</li>
										<li class="nav-item">
											<a href="login.php" class="nav-link">
												<i data-feather="log-out"></i>
												<span>Log Out</span>
											</a>
										</li>
									</ul>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</nav>












			<!-- partial -->

			<div class="page-content">

	        	<div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
	          	</div>
	            <h4 class="mb-3 mb-md-0">Welcome to Dashboard</h4>
       
	            <h2>Add new record:</h2>
				<form action="" method="POST">
					<label>Content1:</label>
					<input type="text" name="cont"><br>
					<label>Content2:</label>
					<input type="text" name="cont1"><br> 
					<label>Content3:</label>
					<input type="text" name="cont2"><br>
					<label>Content4:</label>
					<input type="text" name="cont3"><br> 
					
					<input type="submit"   name="submit">
				</form>


	        </div>
         
        </div>	
	</div>

	<!-- core:js -->
	<script src="assets/vendors/core/core.js"></script>
	<!-- endinject -->
  <!-- plugin js for this page -->
  <script src="assets/vendors/chartjs/Chart.min.js"></script>
  <script src="assets/vendors/jquery.flot/jquery.flot.js"></script>
  <script src="assets/vendors/jquery.flot/jquery.flot.resize.js"></script>
  <script src="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script src="assets/vendors/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendors/progressbar.js/progressbar.min.js"></script>
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="assets/vendors/feather-icons/feather.min.js"></script>
	<script src="assets/js/template.js"></script>
	<!-- endinject -->
  <!-- custom js for this page -->
  <script src="assets/js/dashboard.js"></script>
  <script src="assets/js/datepicker.js"></script>
	<!-- end custom js for this page -->
</body>
</html>    