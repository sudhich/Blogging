<!DOCTYPE html>
<?php
session_start();
$servername="localhost";
$username="root";
$password="";
$database="admin90";
$conn=mysqli_connect($servername,$username,$password,$database);
if ($conn) {
	echo "Connection is successfully";
}
else{
	echo "Connection is not successfull";
}

/*$id=$_GET['id'];
$sql="select * from admin";
$result = mysqli_query($conn, $sql);
$rows=mysqli_fetch_assoc($result);	
echo $rows['name'];
echo $_SESSION['image'];
die;
*/

$id=$_GET['id'];
$sql="SELECT * FROM imagetable";

$result = $conn->query($sql);
    if ($result->num_rows > 0) {
  // output data of each row
  	while($row = $result->fetch_assoc()) {
    	$image=$row["image"];
    	$_SESSION['image']=$image;
		}
	} else{
 		echo "0 results";
	    }



$sql1="select * from admin";
$result1 = $conn->query($sql1);
    if ($result1->num_rows > 0) {
  // output data of each row
  	while($row = $result1->fetch_assoc()) {
    	$name=$row["name"];
    	$_SESSION['name']=$name;
		}
	} else{
 		echo "0 results";
	    }






if (isset($_POST['submit'])) {
	
	$image=$_POST['image'];
	$email=$_POST['email'];
	$name=$_POST['name'];
//	$subject=$_POST['subject'];
    $sql="update admin set name='$name',email_id='$email' where id_image='51'";
    $sql="update imagetable set image='$image' where id='50' ";
	$result = mysqli_query($conn, $sql);
	if ($sql) {
		header('location:update.php');
	}
	else{
		echo "Not updated successfully";
	}








	if ($sql) {
		header('location:imagePro.php');
	}
	else{
		echo "Not updated successfully";
	}
}

?>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="" method="POST">
		<h2>udated page</h2> 
		<label>Name:</label><br>
		<input type="text" name="name" value=""><br>
		<label>Email:</label><br>
		<input type="text" name="email" value=""><br> 
		<label>Image:</label><br>
		<input type="file" name="image" value=""><br>
		<input type="submit" name="submit" value="SUBMIT">
	</form>
</body>
</html>