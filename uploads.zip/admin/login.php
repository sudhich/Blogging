<?php
session_start();

?>
<!DOCTYPE html>
<?php



$servername="localhost";
$username="root";
$password="";
$database="admin90";
$conn=mysqli_connect($servername,$username,$password,$database);
if ($conn) {
   echo "database successfully connected"."<br>";
}else{
   echo "database is not connectred";
}

if (isset($_POST['login'])) {
   $email=$_POST['email'];
   $password=$_POST['password'];
   $name=$_POST['name'];
 
 
   $sql=mysqli_query($conn,"select * from admin where email_id='$email' && password='$password'");
   $reult=mysqli_num_rows($sql);
   if ($reult) {
      $_SESSION["email"]=$email;
      $_SESSION["password"]=$password;
      $_SESSION["name"]=$name;
      header("location:uploadprof.php");
   }else{
     header("location:login.php");
   }
}

?>
<!--<html>
<head>
   <title></title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
   <div class="container">
      <div class="row">
         <div class="col-lg-6">
            <form action="" method="POST">
               <div class="form-group">
                  <label>Name:</label>
                  <input type="text" name="name" class="form-control">
               </div>
               <div class="form-group">
                  <label>Email:</label>
                  <input type="text" name="email" class="form-control">
               </div>
               <div class="form-group">
                  <label>Password:</label>
                  <input type="text" name="password" class="form-control">
               </div>
                
               <button name="login">Login</button>
               
            </form>
         </div>            
      </div>
   </div>
</body>
</html>-->


<!DOCTYPE html>
<html>
<head>
   <title></title>
</head>
<body style="background-color: #E6E6FA;">
   <form method="POST">
      <table align="center" style="border:2px solid black;">
         <div style="padding:10px!important;">
            <tr>
            <th><label>Name:</label></th>
            <td><input type="text" name="name"></td><br>
         </tr>
         <tr>
            <th><label>Email:</label></th><br>
            <td><input type="text" name="email"><br></td>
         </tr>
         <tr>
            <th><label>Password:</label></th><br>
            <td><input type="text" name="password"><br></td>
         </tr>
         <tr>
            <td><button name="login">Login</button></td>
         </tr>
         </div>
   </table>
   </form>
</body>
</html>