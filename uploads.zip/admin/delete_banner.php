<?php
$servername="localhost";
$username="root";
$password="";
$database="admin90";
$conn=mysqli_connect($servername,$username,$password,$database);
/*if ($conn) {
  echo "Connection is successfully";
}
else{
  echo "Connection is not successfull";
}*/

$id=$_GET['id'];
$sql="delete from addbanner where id='$id'";
$result = mysqli_query($conn, $sql);
if ($result) {
  header('location:edit_banner.php');
} 





?>