logout page
<!DOCTYPE html>
<?php 
session_destroy();
header("location:login.php");
?>
<html>
<head>
	<title></title>
</head>
<body>
</body>
</html>